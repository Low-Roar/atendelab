<?php
$host = "localhost";
$porta = "3307";
$banco = "gabrielw";
$usuario = "root";
$senha = "";
    try {
        $pdo = new PDO(
            "mysql:host=$host;dbname$banco;charset=utf8",
            $usuario,
            $senha
        );
        echo "Conexão realiza com sucesso!";
    } catch (PDOException $e) {
        echo "Erro: " . $e->getMessage();
    }